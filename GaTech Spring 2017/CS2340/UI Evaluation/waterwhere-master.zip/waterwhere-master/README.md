# Waterwhere
Waterwhere is GitAtMe's CS2340 Project for the 2017 Spring Semester.

## Status
Currently working on M4 which is concerned with implementing the login screens.

## GitAtMe Members
* Aditya Nadkarni
* Binit Shah
* Shukan Shah
* Vishwa Shah
* Yatharth Dubey
