Weka 3.8
Algorithms: 
tree.J48
meta.adaBoostM1
lazy.IBk
functions.MultilaylerPerceptron
functions.SMO

Preprocessing:
Applied Replace Missing Values filter to data.
Used Resample (No Replacement, seed = 1234) filter to divide training set.

adult dataset: https://archive.ics.uci.edu/ml/datasets/Adult
car evaluation dataset: https://archive.ics.uci.edu/ml/datasets/Car+Evaluation