Code:
Abagail, modified AbaloneTest.java for part 1,
modified flipflop, fourpeaks, and countones for part2.
flappy.py is included for part3, has stopping conditions commented out,
and single cross over is replaced by uniform cross over. I didn't realize we
were supposed to include every model (until the last day), so there are only a couple.

Weka filters used for preprocessing:
Resample,
Normalize,
NominalToBinary,
ReplaceMissingValues


