code: Weka with the multiLayerPerceptrons package
RandomProjection Filter: Sparse1 distribution
MLPAutoencoder Filter:
PrincipalComponent Attribute Selecter
simpleKmeans Clusterer
EM Clusterer
MultiLayerPerceptron for the neural network