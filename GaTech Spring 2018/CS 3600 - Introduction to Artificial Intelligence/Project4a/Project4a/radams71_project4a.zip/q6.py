import Testing
import DecisionTree
Testing.testDummySet1()
Testing.testDummySet2()
Testing.testConnect4()
Testing.testCar()